/**
 * My To Do List App
 *
 * @format
 */

import { useState } from 'react';
import { View } from 'react-native';
import ToDoForm from './ToDoForm';
import ToDoList from './ToDoList';

export default function Index() {

  console.log(ToDoList);

  const [tasks, setTasks] = useState([
    'Do laundry',
    'Go to gym',
    'Walk dog'
  ])

  const addTask = (taskText: string) => {
    setTasks([...tasks, taskText]);
  };

  return (
    <View>
      <ToDoList tasks={tasks} />
      <ToDoForm addTask={addTask} />
    </View>
  );
}